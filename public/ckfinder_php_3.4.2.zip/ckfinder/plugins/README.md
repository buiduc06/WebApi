For example plugins check http://docs.cksource.com/ckfinder3/#!/guide/dev_plugins
